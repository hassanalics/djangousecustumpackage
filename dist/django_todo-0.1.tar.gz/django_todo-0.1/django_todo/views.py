from django.http import HttpResponse

from .models import Reporter

def index(request):
    reporter = Reporter.objects.all()
    return HttpResponse(reporter)